import java.util.Stack;

public class StackExample {
    public static void main(String[] args) {
     
        Stack<Integer> stack = new Stack<>();

        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);
        
        System.out.println("Stack after pushing elements: " + stack);

        int poppedElement = stack.pop();
        System.out.println("Popped element: " + poppedElement);

        // Display the stack after popping an element
        System.out.println("Stack after popping an element: " + stack);
    }
}
