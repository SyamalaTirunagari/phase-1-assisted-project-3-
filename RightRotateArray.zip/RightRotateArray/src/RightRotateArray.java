public class RightRotateArray {
    public static void rightRotateByFiveSteps(int[] arr) {
        int n = arr.length;
        int steps = 5;

       
        int[] temp = new int[n];

       
        for (int i = 0; i < steps; i++) {
            temp[i] = arr[n - steps + i];
        }

        
        for (int i = n - 1; i >= steps; i--) {
            arr[i] = arr[i - steps];
        }

    
        for (int i = 0; i < steps; i++) {
            arr[i] = temp[i];
        }
    }

    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int steps = 5;

        System.out.println("Original Array:");
        for (int num : arr) {
            System.out.print(num + " ");
        }

        rightRotateByFiveSteps(arr);

        System.out.println("\nArray after right-rotating by 5 steps:");
        for (int num : arr) {
            System.out.print(num + " ");
        }
    }
}

