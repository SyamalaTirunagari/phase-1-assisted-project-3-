class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node head;

    LinkedList() {
        head = null;
    }

    void addElement(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            return;
        }
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
    }

    void deleteKey(int key) {
        if (head == null) {
            return; 
        }

        if (head.data == key) {
            head = head.next; 
            return;
        }

        Node current = head;
        while (current.next != null && current.next.data != key) {
            current = current.next;
        }

        if (current.next != null) {
            current.next = current.next.next; 
        }
    }

    void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " -> ");
            current = current.next;
        }
        System.out.println("null");
    }
}

public class DeleteKeyInLinkedList {
    public static void main(String[] args) {
        LinkedList list = new LinkedList();

        list.addElement(1);
        list.addElement(2);
        list.addElement(3);
        list.addElement(4);
        list.addElement(5);

        System.out.println("Original Linked List:");
        list.display();

        int keyToDelete = 3;
        list.deleteKey(keyToDelete);

        System.out.println("Linked List after deleting " + keyToDelete + ":");
        list.display();
    }
}
