class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    Node head;

    CircularLinkedList() {
        head = null;
    }

    void insertSorted(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            head.next = head; 
        }
        else if (data <= head.data) {
     
            newNode.next = head;
            Node current = head;
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            head = newNode;
        }
        else
        {
         
            Node current = head;
            while (current.next != head && current.next.data < data) {
                current = current.next;
            }

         
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    void display() {
        if (head == null) {
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " -> ");
            current = current.next;
        } while (current != head);
        System.out.println(head.data); 
    }
}

public class InsertInSortedCircularLinkedList {
    public static void main(String[] args) {
        CircularLinkedList list = new CircularLinkedList();

        list.insertSorted(3);
        list.insertSorted(1);
        list.insertSorted(5);
        list.insertSorted(2);
        list.insertSorted(4);

        System.out.println("Sorted Circular Linked List:");
        list.display();
    }
}
